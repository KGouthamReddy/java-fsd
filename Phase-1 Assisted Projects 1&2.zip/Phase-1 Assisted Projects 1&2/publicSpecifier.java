package package2;

public class publicSpecifier {
	public void display() {
		System.out.println("This is public access specifiers");
	}
}
