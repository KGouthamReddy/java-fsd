package package2;

public class protectedSpecifier{
	protected void display() {
		System.out.println("This is protected access specifier");
	}
}