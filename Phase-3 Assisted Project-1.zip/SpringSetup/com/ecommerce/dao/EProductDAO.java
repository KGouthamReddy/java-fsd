package com.ecommerce.dao;

import java.sql.ResultSet;    
import java.sql.SQLException;    
import java.util.List;    
import org.springframework.jdbc.core.BeanPropertyRowMapper;    
import org.springframework.jdbc.core.JdbcTemplate;    
import org.springframework.jdbc.core.RowMapper;    
import com.ecommerce.entity.EProduct;   

public class EProductDAO {

        JdbcTemplate template;    
            
        public void setTemplate(JdbcTemplate template) {    
            this.template = template;    
        }    
        
        public List<EProduct> getProducts(){    
            return template.query("select * from eproduct",new RowMapper<EProduct>(){    
                public EProduct mapRow(ResultSet rs, int row) throws SQLException {    
                        EProduct e=new EProduct();    
                    e.setId(rs.getInt(1));    
                    e.setName(rs.getString(2));    
                    e.setPrice(rs.getBigDecimal(3));    
                    e.setDateAdded(rs.getDate(4));    
                    return e;    
                }    
            });    
        }    
}


Step 1.3.6: Creating a Controller class MainController
In the Project Explorer, expand SpringSetup->src->main
Right click on main and choose New->Other
In the Wizard list, choose Java->Class and click on Next
In Package, enter com.ecommerce.controller and in Name enter MainController and click on Finish
Enter the following code:
package com.ecommerce.controller;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ecommerce.entity.EProduct;
import com.ecommerce.dao.EProductDAO;

@Controller
public class MainController {

        
        
           @Autowired    
            EProductDAO eproductDAO;    
           @RequestMapping(value = "/listProducts", method = RequestMethod.GET)
            public String listProducts(ModelMap map)
            {
                    List<EProduct> list= eproductDAO.getProducts();
                model.addAttribute("list",list);  
                return "listProducts";
            }
           }

